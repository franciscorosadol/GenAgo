--Crea base de datos WS

CREATE DATABASE BD_Ejemplo
GO

--Crear tabla Usuarios
CREATE TABLE Usuarios(	Id INT IDENTITY(1,1) PRIMARY KEY,
						Nombre VARCHAR(100) NOT NULL,
						FechaRegistro DATETIME DEFAULT GETDATE());
GO

--Insertar datos de prueba
INSERT INTO Usuarios (Nombre) VALUES ('Juan Perez');
INSERT INTO Usuarios (Nombre) VALUES ('María García');
INSERT INTO Usuarios (Nombre) VALUES ('Carlos Lopez');
INSERT INTO Usuarios (Nombre) VALUES ('Ana Martinez');
INSERT INTO Usuarios (Nombre) VALUES ('Pedro Zanchez');
GO

--Consulta de verificación
USE [BD_Ejemplo]
SELECT * FROM Usuarios
GO