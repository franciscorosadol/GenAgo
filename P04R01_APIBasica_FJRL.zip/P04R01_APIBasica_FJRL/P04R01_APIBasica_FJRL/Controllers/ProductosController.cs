﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace P04R01_APIBasica_CAFL.Controllers
{
    [Route("api/[controller]")] //Define la ruta base del controlador. [controller]se remplaza por el nombre del controlador productos
    [ApiController] //Atributo que habilita caracteristicas automaticas de API Ccomo validacion de modelos
    public class ProductosController : ControllerBase
    { //Metodo Get all
        [HttpGet] //atributo que indica que el metodo responde a solicitudes HTTP
        public ActionResult<IEnumerable<Producto>> GetProductos() //Tipo de retorno que permite devolver tanto el objeto como codigos de estado
        {
            var productos = new List<Producto>
            {

            new Producto { Id = 1, Nombre = "Laptop", Precio = 15000.00M },
            new Producto { Id = 2, Nombre = "Mouse", Precio = 250.50M },
            new Producto { Id = 3, Nombre = "Teclado", Precio = 250.50M }

            };
            return Ok(productos); //este metodo devuelve la respuesta HTTP 200(Success) con la data


        }
        [HttpGet("{id}")]
        public ActionResult<Producto> GetProducto(int id)
        {
            var producto = new Producto
            {
                Id = id,
                Nombre = "Producto" + id,
                Precio = 100.00M * id
            };
            return Ok(producto);
        }
    } //Fin de la clase

    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Precio { get; set; }
    }

}//Fin del namespace